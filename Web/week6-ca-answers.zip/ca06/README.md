# DDA CA 06 
In this activity, you will start to make your own recipe/player profile. You will be introduced to five common HTML tags; headings, paragraphs, image, ordered lists and unordered lists. 

Based on the wireframe on the right, try to create your own profile card
Start by forking the base template [Bit.ly Receipe Sample](http://bit.ly/id-MakeARecipe)

## Submissions 
- Submit a zip of the HTML and related files titled `“Wk06-studentid-studentname-make-a-card.zip”`
- `E.g DDAWk06-16012010D-UncleRoger-make-a-card.zip`
- Submit the file in Brightspace
- You may download your repl.it file once you are satisfied :)
/*
Based on your assignment 1, create `literal objects` of your class models. 
Create appropriate literal objects and for each property, indicate the appropriate data types to use.
Eg. converting SimpleLeaderBoard
*/
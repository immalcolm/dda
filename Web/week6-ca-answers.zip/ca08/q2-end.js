function SimpleLeaderBoard(userName, score, timestamp) {
    this.userName = userName;
    this.score = score;
    this.timestamp = timestamp;
}

let leaderboard = []

const timestamp = Math.floor(Date.now() / 1000);
let simpleLeaderBoard1 = new SimpleLeaderBoard("Alfred", 100, timestamp);
let simpleLeaderBoard2 = new SimpleLeaderBoard("Bob", 200, timestamp);

leaderboard.push(simpleLeaderBoard1);
leaderboard.push(simpleLeaderBoard2);

console.log(leaderboard);
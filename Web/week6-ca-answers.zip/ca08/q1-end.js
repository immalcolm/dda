const timestamp = Math.floor(Date.now() / 1000);

let SimpleLeaderBoard = {
  userName: "Alfred",
  score: 100,
  updatedOn: timestamp,
};

console.log(SimpleLeaderBoard);
/*

public class SimpleLeaderBoard{

    public string userName { get; set; }
    public int score { get; set; }
    public long timestamp { get; set; }

    public SimpleLeaderBoard(string userName, int score, long timestamp){
        this.userName = userName;
        this.score = score;
        this.timestamp = timestamp;
    }

}
*/

/* 
Based on your assignment 1, create `function based objects` of your class models, indicate the appropriate data types to use. 
Create sample object variables based on your models
You may assume your own property values. 
*/